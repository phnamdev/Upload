<template>
  <div class="ms-schedule">
    <table
      class="ms-schedule-table ms-outer-table"
      role="presentation"
    >
      <tbody>
        <tr>
          <td class="ms-left-indent">
            <schedule-indent />
          </td>
          <td>
            <schedule-header :weekdays="weekdays" />
          </td>
        </tr>
        <tr>
          <td>
            <schedule-time
              ref="timeCellsWrap"
              :times="times"
            />
          </td>
          <td>
            <schedule-content
              ref="contentWrap"
              :weekdays="weekdays"
              :time-start="timeStart"
              :time-end="timeEnd"
              :time-cells="timeCells"
              :step="step"
              :step-height="stepHeight"
              :events="events"
            />
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script lang="ts">
/* eslint-disable */
import { defineComponent, computed, ref, onMounted, toRefs, Ref, PropType, watch, ComponentPublicInstance } from 'vue'
import dayjs from 'dayjs'
import localeData from 'dayjs/plugin/localeData'
import { throttle } from 'lodash'
import ScheduleHeader from './schedule-header.vue'
import ScheduleContent from './schedule-content.vue'
import ScheduleTime from './schedule-time.vue'
import ScheduleIndent from './schedule-indent.vue'
import type { ScheludeType, Event } from './types'

const MIN_START_HOUR = 7
dayjs.extend(localeData)

export default defineComponent({
  name: 'MsSchedule',

  components: {
    ScheduleHeader,
    ScheduleContent, 
    ScheduleTime, 
    ScheduleIndent
  },

  props: {
    modelValue: {
      type: Date,
      default: new Date()
    },

    // Danh sách các event
    events: {
      type: Array as PropType<Event[]>,
      default: () => []
    },

    // Bước nhày thời gian của lịch(minute)
    step: {
      type: Number,
      default: 15
    },

    // Chiều cao mỗi dòng
    stepHeight: {
      type: Number,
      default: 32
    },

    // Kiểu lịch
    type: {
      type: String as PropType<ScheludeType>,
      default: 'week'
    }
  },

  setup (props) {
    const timeCellsWrap: Ref<ComponentPublicInstance | null> = ref(null)
    const contentWrap: Ref<ComponentPublicInstance | null> = ref(null)
    const { step, type } = props
    const { modelValue } = toRefs(props)
    const times: Ref<any[]> = ref([])
    const timeCells: Ref<any[]> = ref([])
    const weekdayNames: string[] = dayjs.localeData().weekdays()

    const startWeek = computed(() => {
      let start = dayjs(modelValue.value as Date)

      switch (type) {
        case 'week':
          start = start.startOf(type)
      }

      return start
    })

    const endWeek = computed(() => {
      let end = dayjs(modelValue.value as Date)

      switch (type) {
        case 'week':
          end = end.endOf(type)
      }

      return end
    })

    const weekdays = computed(() => {
      const days: any[] = []
      let day = startWeek.value.clone()

      while (day.isBefore(endWeek.value)) {
        days.push({
          DataDate: day.toDate().getTime(),
          DayName: weekdayNames[day.day()],
          Date: day.format('DD/MM/YYYY')
        })

        day = day.add(1, 'day')
      }

      return days
    })


    const timeStart = computed(() => {
      return dayjs(startWeek.value.toDate().setHours(MIN_START_HOUR, 0, 0, 0))
    })

    const timeEnd = computed(() => {
      return timeStart.value.endOf('day')
    })


    watch([timeStart, timeEnd], ([startTime, endTime]) => {
      let timeIterator = startTime.clone()

      while (timeIterator.isBefore(endTime, 'minute')) {
        const minutes = timeIterator.minute()
        const isEmptySlot = (minutes / step) % 2

        times.value.push({
          IsEmptySlot: isEmptySlot,
          text: isEmptySlot ? '' : timeIterator.format('HH:mm')
        })

        timeIterator = timeIterator.add(step, 'minute')
      }

    }, { immediate: true})


    debugger

    onMounted(() => {
      if (contentWrap.value !== null) {
        contentWrap.value.$el.onscroll = throttle(event => {
          if (timeCellsWrap.value !== null) {
            timeCellsWrap.value.$el.scroll(0, event.target.scrollTop)
          }
        }, 50)
      }
    })

    return {
      timeCells,
      times,
      timeCellsWrap,
      contentWrap,
      weekdays,
      timeStart,
      timeEnd,
    }
  }
})
</script>

<style lang="scss">
.ms-schedule {
  background-color: #fff;
  border: 1px solid #d0d0d0;

  .ms-schedule-table {
    border: 0 none;
    border-collapse: separate;
    border-spacing: 0;
    margin: 0;
    table-layout: fixed;
    width: 100%;

    .ms-time-slots {
      font-weight: bold;
      color: #62768e;
    }

    .ms-left-indent {
      width: 85px; 
    }
  }
}
</style>

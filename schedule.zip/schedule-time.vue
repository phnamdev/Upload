<template>
  <div
    ref="timeCellsWrap"
    class="ms-time-cells-wrap"
    style="height: 393px;"
  >
    <table class="ms-schedule-table">
      <tbody>
        <tr
          v-for="(time, idx) in times"
          :key="idx"
        >
          <td
            v-if="time.IsEmptySlot"
            class="ms-time-cells ms-time-slots"
          >
            &nbsp;
          </td>
          <td
            v-else
            class="ms-time-slots"
          >
            <span>{{ time.text }}</span>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'ScheduleTime',

  props: {
    times: {
      type: Array,
      default: () => []
    }
  }
})
</script>

<style lang="scss">
.ms-time-cells-wrap {
  position: relative;
  overflow: hidden;

  table {
    tr {
      td {
        background-color: #fff;
        border-color: #d0d0d0;
        border-style: solid;
        border-width: 0 1px 1px 0;
        font-size: 13px;
        height: 32px;
        text-align: center;
        vertical-align: top;
        border-bottom-color: transparent;

        &.ms-time-cells {
          border-bottom-color: #d0d0d0;
        }
      }

      &:last-child {
        td {
          border-bottom-width: 0;
        }
      }
    }
  }
}
</style>

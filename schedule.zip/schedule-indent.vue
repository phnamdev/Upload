<template>
  <div class="ms-left-indent-wrap">
    <table class="ms-schedule-table ">
      <tbody>
        <tr>
          <td class="ms-header-cells ms-disable-dates" />
        </tr>
        <tr>
          <td
            class="ms-all-day-cells ms-disable-dates ms-animate"
            style="height: 0em;"
          >
            <div
              class="ms-all-day-appointment-section ms-appointment-expand ms-icons ms-disable"
              tabindex="0"
              role="list"
              aria-disabled="false"
              aria-label="Expand section"
            />
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  name: 'ScheduleIndent'
}
</script>

<style lang="scss">
.ms-left-indent-wrap {
  table {
    tbody {
      td {
        background-color: #fff;
        border-color: #dadada;
        border-style: solid;
        border-width: 0 1px 1px 0;

        &.ms-header-cells {
          border-bottom-width: 0;
          height: 80px;
        }
      }
    }
  }
}
</style>

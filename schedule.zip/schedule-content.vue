<template>
  <div
    class="ms-content-wrap"
    style="height: 393px;"
  >
    <table class="ms-schedule-table ms-content-table">
      <colgroup>
        <col
          v-for="(w, idx) in weekdays"
          :key="idx"
        >
      </colgroup>
      <thead>
        <tr>
          <td
            v-for="(row, idx) in scheduleEvents"
            :key="idx"
            class="ms-day-wrapper"
          >
            <div class="ms-appointment-wrapper">
              <schedule-event
                v-for="(event, index) in row"
                :key="index"
                :event="event"
                @click.stop="onClickEvent(event)"
              />
            </div>
          </td>
        </tr>
      </thead>
      <tbody>
        <tr
          v-for="(timeCell, idx) in timeCells"
          :key="idx"
          role="row"
        >
          <td
            v-for="(col, ix) in timeCell"
            :key="ix"
            role="gridcell"
            aria-selected="false"
            colspan="1"
            class="ms-work-cells ms-alternate-cells"
            :data-date="col.date.getTime()"
            @click.stop="onAddNewEvent(col.date, col.toDate)"
          />
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script lang="ts">
/* eslint-disable */
// @ts-nocheck
import { computed, defineComponent, PropType, ref, Ref, toRefs, watch } from 'vue'
import type { WeekDay } from './types'
import ScheduleEvent from './schedule-event.vue'
import type { Event, ScheduleEvent as ScheduleEvt } from './types'
import dayjs from 'dayjs'

const ADD_SCHEDULE_EVENT = 'addScheduleEvent'
const EDIT_SCHEDULE_EVENT = 'editScheduleEvent'

export default defineComponent({
  name: 'ScheduleContent',

  emits: [ADD_SCHEDULE_EVENT, EDIT_SCHEDULE_EVENT],

  components: {
    ScheduleEvent
  },

  props: {
    weekdays: {
      type: Array as PropType<WeekDay[]>,
      default: () => []
    },

     events: {
      type: Array as PropType<Event[]>,
      default: () => []
    },

    timeStart: dayjs,

    timeEnd: dayjs,

    step: Number,

    stepHeight: Number
  },

  setup (props, { emit }) {
    const timeCells: Ref<any[]> = ref([])
    const { step, stepHeight } = props
    const { timeStart, timeEnd, weekdays, events } = toRefs(props)
    const totalDays = computed(() => weekdays.value.length)

    watch([timeStart, timeEnd], ([startTime, endTime]) => {
      let timeIterator = startTime.clone()

      while (timeIterator.isBefore(endTime, 'minute')) {
        const cells = []

        for (let i = 0; i < totalDays.value; i++) {
          const today = timeIterator.add(i, 'day')
          let toDate = today.add(step, 'minute')

          toDate = today.date() == toDate.date() ? toDate : today.endOf('day')
          cells.push({
            date: today.toDate(),
            toDate: toDate.toDate()
          })
        }

        timeCells.value.push(cells)
        timeIterator = timeIterator.add(step, 'minute')
      }
    }, { immediate: true })


    const scheduleEvents = computed(() => {
      const twoDimensionEvent: ScheduleEvt[][] = []

      for (let i = 0; i < totalDays.value; i++) {
        twoDimensionEvent.push([])
      }


       events.value.map(event => {
        const startEventDay = dayjs(
            dayjs(event.StartTime as Date)
            .toDate()
            .setHours(7, 0, 0, 0)
        )
        const eventStart = dayjs(event.StartTime as Date)
        const eventEnd = dayjs(event.EndTime as Date)
        const day = eventStart.diff(timeStart.value, 'day')

        if (day < totalDays.value) {
            twoDimensionEvent[day].push({
                EventName: event.EventName,
                Organizer: event.Organizer,
                TimeLabel: `${eventStart.format('HH:mm')} - ${eventEnd.format(
                'HH:mm'
                )}`,
                ArialLabel: `${event.EventName} bắt đầu vào ${eventStart.format(
                'HH:mm ngày DD-MM-YYYY'
                )} và kết thúc vào ${eventEnd.format('HH:mm ngày DD-MM-YYYY')}`,
                Style: {
                top: `${(eventStart.diff(startEventDay, 'minute') / step) *
                    stepHeight}px`,
                height: `${(eventEnd.diff(eventStart, 'minute') / step) * stepHeight}px`
                }
            })
        }
    })

        return twoDimensionEvent
    })

    const onAddNewEvent = (time: Date, toTime: Date) => {
      console.log(`${time} - ${toTime}`)
      emit(ADD_SCHEDULE_EVENT, { from: time, to: toTime})
    }

    const onClickEvent = (event: Event) => {
      console.log(event.EventName)
      emit(EDIT_SCHEDULE_EVENT, event)
    }

    return {
        timeCells,
        scheduleEvents, 
        onAddNewEvent, 
        onClickEvent
    }
  }
})
</script>

<style lang="scss">
.ms-content-wrap {
  overflow: auto;
  position: relative;

  table {
    tbody {
      tr {
        td {
          &.ms-work-cells {
            background-color: #f2f1f7;
            border-color: #d0d0d0;
            border-style: solid;
            border-width: 0 0 1px 1px;
            font-size: 13px;
            height: 32px;
            width: 36px;
            text-align: center;
          }

          &:first-child {
            border-left-width: 0;
          }
        }

        &:nth-child(4n + 1),
        &:nth-child(4n + 2) {
          td {
            background-color: #fff;
          }
        }

        &:last-child {
          td {
            border-bottom-width: 0;
          }
        }
      }
    }

    thead {
      tr {
        td {
          &.ms-day-wrapper {
            height: 0;
            margin: 0;
            padding: 0;
            position: relative;
          }
        }
      }
    }
  }
}
</style>

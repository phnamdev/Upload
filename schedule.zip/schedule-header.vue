<template>
  <div
    class="ms-date-header-container"
    style="padding-right: 16px;"
  >
    <div
      class="ms-date-header-wrap ms-all-day-auto"
      style="border-right-width: 1px;"
    >
      <table class="ms-schedule-table">
        <colgroup>
          <col
            v-for="day in weekdays"
            :key="day.DayName"
          >
        </colgroup>
        <thead>
          <!-- <tr>
            <td
              class="ms-all-day-appointment-wrapper"
              data-date="1518627600000"
            />
          </tr> -->
        </thead>
        <tbody>
          <tr class="ms-header-row">
            <td
              v-for="day in weekdays"
              :key="day.DayName"
              colspan="1"
              class="ms-header-cells"
              :data-date="day.DataDate"
            >
              <div class="ms-header-day">
                {{ day.DayName }}
              </div>
              <div
                class="ms-header-date ms-navigate"
                role="link"
              >
                {{ day.Date }}
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, PropType } from 'vue'
import type { WeekDay } from './types'

export default defineComponent({
  name: 'ScheduleHeader',

  props: {
    weekdays: {
      type: Array as PropType<WeekDay[]>,
      default: () => []
    }
  }
})
</script>

<style lang="scss">
.ms-date-header-wrap {
  border-color: #dadada;
  border-style: solid;
  border-width: 0;
  position: relative;

  table {
    tbody {
      tr {
        td {
          background-color: #fff;
          border-color: #dadada;
          border-style: solid;
          border-width: 0 0 1px 1px;
          text-align: center;

          &:first-child {
            border-left-width: 0;
          }

          &.ms-header-cells {
            background-color: #f1f2f7;
            font-size: 12px;
            height: 80px;
            padding: 5px;

            .ms-header-day {
              font-size: 13px;
              font-weight: bold;
              color: #4e5b6a;
            }

            .ms-header-date {
              color: #62768e;
            }
          }
        }
      }
    }
  }
}
</style>

<template>
  <div
    class="ms-appointment"
    role="button"
    tabindex="0"
    aria-readonly="false"
    aria-selected="false"
    aria-grabbed="true"
    :aria-label="event.ArialLabel"
    :style="event.Style"
  >
    <div class="ms-event-resize ms-top-handler">
      <div class="ms-top-bottom-resize" />
    </div>
    <div class="ms-appointment-details">
      <div
        class="ms-subject"
      >
        {{ event.EventName }}
      </div>
      <div class="ms-organizer">
        ({{ event.Organizer }})
      </div>
      <div class="ms-location" />
    </div>
    <div class="ms-event-resize ms-bottom-handler">
      <div class="ms-top-bottom-resize" />
    </div>
  </div>
</template>

<script lang="ts">
import { PropType } from 'vue'
import type { ScheduleEvent } from './types'
const defaultEvent: ScheduleEvent = {
  EventName: '',
  TimeLabel: '',
  Organizer: '',
  ArialLabel: '',
  Style: {}
}

export default {
  name: 'ScheduleEvent',

  props: {
    event: {
      type: Object as PropType<ScheduleEvent>,
      default: (): ScheduleEvent => defaultEvent
    }
  }
}
</script>

<style lang="scss">
.ms-appointment {
  overflow: hidden;
  position: absolute;
  background-color: #e8e1fd;
  width: 100%;
  border-left: 4px solid #8a6bf6;
  left: 0%;
  display: flex;
  align-items: center;
  justify-content: center;

  .ms-appointment-details {
    display: flex;
    justify-content: center;
    flex-direction: column;
    align-items: center;

    .ms-subject {
      font-weight: bold;
      color: #8a6bf6;
    }

    .ms-organizer {
      color: #62768e;
    }
  }
}
</style>
